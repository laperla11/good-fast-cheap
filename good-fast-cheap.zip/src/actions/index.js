export const toggleSwitch = (label) => ({
  type: "TOGGLE_SWITCH",
  label,
});
